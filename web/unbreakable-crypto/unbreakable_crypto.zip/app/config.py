FLAG = "shellmates{just_for_testing}"

URL = "http://localhost:8000"
